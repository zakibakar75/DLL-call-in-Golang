// file: square.cpp
// square.cpp : Defines the exported functions for the DLL application.
#include "stdafx.h"

int __stdcall dll_math_example(int the_x, int the_y, int the_a, int the_b)
{
	return (the_x + the_y + the_a + the_b);
}

int __stdcall dll_function_example(void)
{
	return 200;
}


